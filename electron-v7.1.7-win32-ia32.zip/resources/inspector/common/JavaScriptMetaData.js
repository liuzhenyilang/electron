export class JavaScriptMetaData{signaturesForNativeFunction(name){}
signaturesForInstanceMethod(name,receiverClassName){}
signaturesForStaticMethod(name,receiverConstructorName){}}